# Vaktija Premium (Android — v1.0)

**Vaktija Premium** je Android aplikacija sa identičnim izgledom, ikonicom i namaskim vremenima kao zvanična **vaktija.ba** aplikacija, uz **e-Diyanet** obavijesni panel i dinamičku ikonicu odbrojavanja u statusnoj traci.
