# Keep Vaktija API models
-keep class ba.vaktija.nova.model.** { *; }
